import { useState } from "react";

export default function Brokers() {
  const [data, setData] = useState([]);

  const loadBrokers = async () => {
    try {
      const res = await fetch("http://localhost:1880/brokers");
      const json = await res.json();
      setData(json);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Corretoras</h1>

      <button onClick={loadBrokers}>Carregar</button>

      <pre style={{ marginTop: 20, background: "#eee", padding: 10 }}>
        {JSON.stringify(data, null, 2)}
      </pre>
    </div>
  );
}
