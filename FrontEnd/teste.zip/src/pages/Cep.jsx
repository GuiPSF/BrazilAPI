import { useState } from "react";

export default function Cep() {
  const [cep, setCep] = useState("");
  const [data, setData] = useState(null);

  const buscarCep = async () => {
    try {
      const clean = cep.replace(/[^0-9]/g, "");
      const res = await fetch(`http://localhost:1880/cep/v2/${clean}`);
      const json = await res.json();
      setData(json);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Buscar CEP</h1>

      <input
        type="text"
        placeholder="Digite o CEP"
        value={cep}
        onChange={(e) => setCep(e.target.value)}
      />

      <button style={{ marginLeft: 10 }} onClick={buscarCep}>
        Buscar
      </button>

      <pre style={{ marginTop: 20, background: "#eee", padding: 10 }}>
        {JSON.stringify(data, null, 2)}
      </pre>
    </div>
  );
}
