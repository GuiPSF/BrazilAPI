import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Node-RED Client</h1>

      <ul>
        <li><Link to="/brokers">Catálogo de Corretoras</Link></li>
        <li><Link to="/cep">Buscar CEP</Link></li>
      </ul>
    </div>
  );
}
