import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Brokers from "./pages/Brokers";
import Cep from "./pages/Cep";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/brokers" element={<Brokers />} />
        <Route path="/cep" element={<Cep />} />
      </Routes>
    </BrowserRouter>
  );
}
